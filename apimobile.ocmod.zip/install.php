<?php 

$this->db->query("CREATE TABLE " . DB_PREFIX."user_token_mob_api ( user_id INT NOT NULL PRIMARY KEY, token VARCHAR(32) NOT NULL )");
 
?>