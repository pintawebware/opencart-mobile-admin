<?php

class ControllerModuleApimoduleApimodule extends Controller
{
    public function index()
    {
        header("Access-Control-Allow-Origin: *");

            $this->load->model('module/apimodule/apimodule');
            $data['orders'] = $this->model_module_apimodule_apimodule->getOrders();
        echo json_encode($data['orders'])  ;

    }
    public function order()
    {
        $id = $_REQUEST['id'];
        header("Access-Control-Allow-Origin: *");

        $this->load->model('module/apimodule/apimodule');
        $data['order'] = $this->model_module_apimodule_apimodule->getOrderById($id);
        if($data['order']){
            echo json_encode($data['order'])  ;
        }else{
            echo json_encode('Order with id(' .$id. ') not found.');
        }

    }
}
