<?php
class ModelModuleApimoduleApimodule extends Model {
    /**
     * @api {post} index.php?route=module/apimodule  getOrders
     * @apiName GetOrders
     * @apiGroup All
     *
     *
     * @apiSuccess {String} firstname Firstname of the client.
     * @apiSuccess {String} lastname  Lastname of the client.
     * @apiSuccess {Number} order_id  ID of the order.
     * @apiSuccess {Number} store_id  ID of the store.
     * @apiSuccess {String} email     Client's email.
     * @apiSuccess {String} telephone  Client's phone.
     * @apiSuccess {String} payment_company  Company of the User.
     * @apiSuccess {String} payment_address_1  First payment address.
     * @apiSuccess {String} payment_city  Payment city.
     * @apiSuccess {String} payment_method  Payment method.
     * @apiSuccess {String} shipping_method  Shipping method.
     * @apiSuccess {String} total  Total sum of the order.
     *
     * @apiSuccessExample Success-Response:
     *     HTTP/1.1 200 OK
     *   {
     *      "0" : "Array"
     *      {
     *         "order_id" : "1"
     *         "store_id" : "0"
     *         "firstname" : "Anton"
     *         "lastname" :"Kiselev"
     *         "email" : "anton.kiselev@pinta.com.ua"
     *         "telephone" : "+380985739209"
     *         "payment_firstname" : "Anton"
     *         "payment_lastname" : "Kiselev"
     *         "payment_company" : "Pinta"
     *         "payment_address_1" : "address"
     *         "payment_city" : "dnepropetrovsk"
     *         "payment_method" : "Оплата при доставке"
     *         "shipping_method" : "Доставка с фиксированной стоимостью доставки"
     *         "total" : "106.0000"

     *        }
     *    }
     *
     */
    public function getOrders () {
        $orders=array();
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order ORDER BY order_id");
       // foreach ($query->rows as $result) {
         //   $orders[] = $result;
        //}
        return $query->rows;
    }
    /**
     * @api {post} index.php?route=module/apimodule/order  getOrderById
     * @apiName GetOrderById
     * @apiGroup All
     *
     ** @apiParam {Number} id Order unique ID.
     *
     * @apiSuccess {String} firstname Firstname of the client.
     * @apiSuccess {String} lastname  Lastname of the client.
     * @apiSuccess {Number} order_id  ID of the order.
     * @apiSuccess {Number} store_id  ID of the store.
     * @apiSuccess {String} email     Client's email.
     * @apiSuccess {String} telephone  Client's phone.
     * @apiSuccess {String} payment_company  Company of the User.
     * @apiSuccess {String} payment_address_1  First payment address.
     * @apiSuccess {String} payment_city  Payment city.
     * @apiSuccess {String} payment_method  Payment method.
     * @apiSuccess {String} shipping_method  Shipping method.
     * @apiSuccess {String} total  Total sum of the order.
     *
     * @apiSuccessExample Success-Response:
     *     HTTP/1.1 200 OK
     *   {
     *         "order_id" : "1"
     *         "store_id" : "0"
     *         "firstname" : "Anton"
     *         "lastname" :"Kiselev"
     *         "email" : "anton.kiselev@pinta.com.ua"
     *         "telephone" : "+380985739209"
     *         "payment_firstname" : "Anton"
     *         "payment_lastname" : "Kiselev"
     *         "payment_company" : "Pinta"
     *         "payment_address_1" : "address"
     *         "payment_city" : "dnepropetrovsk"
     *         "payment_method" : "Оплата при доставке"
     *         "shipping_method" : "Доставка с фиксированной стоимостью доставки"
     *         "total" : "106.0000"
     *    }
     *
     */
    public function getOrderById ($id) {
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order WHERE order_id = " . $id . " ORDER BY order_id");

        return $query->rows;
    }
}